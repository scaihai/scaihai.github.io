
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { PROJECTS, ENGINEER_NAME, ENGINEER_ROLE, BIO, EXPERIENCES, SKILLS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

const SYSTEM_INSTRUCTION = `
You are the AI assistant for ${ENGINEER_NAME}, a ${ENGINEER_ROLE}.
Your goal is to help recruiters and collaborators learn more about Alex.

Bio: ${BIO}

Experience:
${EXPERIENCES.map(e => `- ${e.role} at ${e.company} (${e.period}): ${e.achievements.join('. ')}`).join('\n')}

Skills:
${SKILLS.map(s => `- ${s.name} (${s.level}/100)`).join('\n')}

Projects:
${PROJECTS.map(p => `- ${p.title}: ${p.description} Tech: ${p.techStack.join(', ')}`).join('\n')}

Be professional, concise, and enthusiastic. If you don't know something specific about Alex that isn't in the context, politely suggest contacting Alex directly via the contact form. Use Markdown for formatting.
`;

export const askAssistant = async (message: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: message,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    return response.text || "I'm sorry, I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The AI assistant is currently experiencing some technical difficulties. Please reach out to me via email!";
  }
};
