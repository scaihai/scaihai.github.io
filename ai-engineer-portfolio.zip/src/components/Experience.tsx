import { motion } from 'motion/react';

const EXPERIENCES = [
  {
    role: "Senior AI Engineer",
    company: "Anthropic / Equivalent",
    period: "2023 - Present",
    description: "Leading the development of highly reliable agentic architectures for code-generation models. Designed and implemented synthetic data generation pipelines.",
  },
  {
    role: "Machine Learning Engineer",
    company: "Scale AI / Equivalent",
    period: "2021 - 2023",
    description: "Architected distributed training loops and RLHF integration points. Reduced inference latency by 40% via model distillation and TensorRT optimizations.",
  },
  {
    role: "Software Engineer",
    company: "Stripe",
    period: "2019 - 2021",
    description: "Built fraud detection microservices using streaming analytics paradigms. Core contributor to the real-time alerting infrastructure.",
  }
];

export default function Experience() {
  return (
    <section id="experience" className="py-24 px-6 bg-white border-y border-gray-100">
      <div className="max-w-4xl mx-auto">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.6 }}
        >
          <h2 className="font-display text-4xl font-bold tracking-tight mb-16">Experience</h2>
          
          <div className="space-y-12">
            {EXPERIENCES.map((exp, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-8 group"
              >
                <div className="col-span-1 text-gray-400 font-mono text-sm mt-1">
                  {exp.period}
                </div>
                <div className="col-span-3">
                  <h3 className="text-xl font-bold font-display tracking-tight text-gray-900 group-hover:text-blue-600 transition-colors">
                    {exp.role}
                  </h3>
                  <div className="text-gray-500 font-medium mb-4">{exp.company}</div>
                  <p className="text-gray-600 leading-relaxed text-balance">
                    {exp.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
